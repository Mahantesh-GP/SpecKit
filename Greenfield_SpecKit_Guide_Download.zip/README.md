# GitHub Spec Kit — Greenfield Developer Job Aid

> **Status:** EA pilot-informed draft for review, **not** approved enterprise policy. **Scope:** Greenfield (new application). The separate Brownfield guide covers existing applications.

## The problem

A new application has no established architecture or implementation to inspect. Starting to code from an ambiguous idea can lead to inconsistent requirements, architecture decisions and tasks.

## The fix

**Confirm the problem and scope → agree project engineering guardrails → Specify → Clarify → Plan → Tasks → Analyze → Implement → validate and review.** This is a recommended working sequence, not proof that every command was executed for the separate .NET Todo pilot.

## Start here

| You need to… | Open |
|---|---|
| Define a bounded new product / first feature | [01 · Scope and readiness](greenfield/01-scope-readiness.md) |
| Set project-level engineering guardrails | [02 · Constitution](greenfield/02-constitution.md) |
| Describe behavior without prescribing implementation | [03 · Specify and Clarify](greenfield/03-specify-clarify.md) |
| Design architecture and break down implementation | [04 · Plan and Tasks](greenfield/04-plan-tasks.md) |
| Review consistency and implement | [05 · Analyze and Implement](greenfield/05-analyze-implement.md) |
| Validate, record evidence and raise a PR | [06 · Verification and handoff](greenfield/06-verification-handoff.md) |
| Start another feature | [07 · Subsequent features](greenfield/07-subsequent-features.md) |
| Copy a reusable Copilot prompt | [Prompt library](prompts/README.md) |
| Understand what the pilots actually demonstrated | [Pilot evidence and limitations](examples/pilot-evidence.md) |

## Greenfield path

```mermaid
flowchart TD
 A[Approved problem and bounded scope] --> B[Constitution: proposed project rules]
 B --> C[Specify: requirements and scenarios]
 C --> D[Clarify: resolve ambiguity]
 D --> E[Plan: technical design]
 E --> F[Tasks: implementable work]
 F --> G[Analyze: review consistency]
 G --> H[Implement: code and tests]
 H --> I[Run tests and inspect changes]
 I --> J[PR, QA, owner review and evidence]
```

## Use this correctly

- **Commands** require Spec Kit to be installed/configured in your workspace; this guide does not install it.
- **Copilot prompts** in this repository are proposed reusable guidance, not proof of executed pilot prompts.
- **Analyze** reviews artifacts; it does not replace tests, approvals or runtime verification.
- **ADO/PR** integration follows your team's existing permissions and review process. Never assume automatic synchronization.
- **Evidence first:** see [SOURCE-MAP.md](SOURCE-MAP.md) and the unchanged [Master Evidence](evidence/SpecKit_Pilots_Master_Evidence_2026-10-28.md).

## Repository layout

`greenfield/` practical stages · `prompts/` copy/paste prompts · `examples/` carefully scoped pilot evidence · `evidence/` original master register.
