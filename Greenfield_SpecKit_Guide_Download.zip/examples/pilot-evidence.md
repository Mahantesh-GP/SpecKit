# Pilot evidence and limitations

## Separate .NET Todo sample — closest Greenfield reference

The [Master Evidence](../evidence/SpecKit_Pilots_Master_Evidence_2026-10-28.md) identifies an **earlier .NET 8 + React + SQL Server Todo** sample and an end-to-end Spec Kit/ADO experiment. The original screenshot-to-feature mapping, full prompt transcripts, exact test outcomes and release status **have not been fully reverified**. Do not publish specific greenfield feature counts, test passes or approvals from this track without source review.

## Different Todo application — do not merge

A separate **Python/Flask/Jinja2/SQLite/pytest** Todo track has screenshot-derived Constitution, Specify, Clarify, Plan, Tasks, Analyze and Implement evidence. The reported **16/16** mapping was requirements-to-tasks, not test coverage. The **27 passing tests** were an existing baseline in a separate Brownfield experiment, not proof of new feature validation. Its AMD-001 amendment was not approved or implemented.

## Adaptive Workflow / DocNav — Brownfield only

This was an existing .NET/Azure Durable Functions solution; its HTTP 202 pilot outcome does **not** demonstrate Greenfield readiness.

**Use of this guide:** process and prompts are recommended practice informed by these observations, not a claim of a fully validated greenfield rollout.

[Home](../README.md)
