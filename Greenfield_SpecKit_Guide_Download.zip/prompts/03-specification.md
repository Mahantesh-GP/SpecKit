# Specification — proposed reusable Copilot prompt

> **Status:** Recommended adaptation; not a verbatim executed pilot prompt. Replace placeholders.

```text
For the approved greenfield feature [FEATURE], help prepare /speckit.specify. Describe user needs, behavior, acceptance scenarios, errors and nonfunctional constraints grounded in [APPROVED REQUIREMENTS]. Do not prescribe unapproved implementation. Flag assumptions and trace each requirement to the supplied source. Output: proposed feature boundary, scenarios, ambiguity list and owner questions.
```

**Reference:** [Master Evidence](../evidence/SpecKit_Pilots_Master_Evidence_2026-10-28.md) for observed Spec Kit stages and limitations; [source map](../SOURCE-MAP.md) for guidance provenance.

[Prompt index](README.md) · [Home](../README.md)
