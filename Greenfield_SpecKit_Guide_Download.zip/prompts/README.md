# Copy/paste Copilot prompts

These are **proposed prompts**, not confirmed transcripts. Do not run read-only prompts as write operations.

- [Scope discovery](01-scope-discovery.md)
- [Constitution context](02-constitution.md)
- [Specification](03-specification.md)
- [Clarification](04-clarification.md)
- [Plan review](05-plan-review.md)
- [Tasks review](06-tasks-review.md)
- [Analyze review](07-analyze-review.md)
- [Verification evidence](08-verification.md)
- [Next-feature discovery](09-next-feature-discovery.md)

[Home](../README.md)
