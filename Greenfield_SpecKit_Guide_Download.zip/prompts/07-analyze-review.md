# Analyze review — proposed reusable Copilot prompt

> **Status:** Recommended adaptation; not a verbatim executed pilot prompt. Replace placeholders.

```text
Read spec, plan, tasks and Constitution in read-only mode before implementation. Identify contradictions, missing requirement-to-task mappings, unaddressed clarifications, contract mismatches and untestable acceptance criteria. Rank findings by severity and cite exact artifact sections. Recommend corrections for developer review. This is static consistency analysis, not test execution.
```

**Reference:** [Master Evidence](../evidence/SpecKit_Pilots_Master_Evidence_2026-10-28.md) for observed Spec Kit stages and limitations; [source map](../SOURCE-MAP.md) for guidance provenance.

[Prompt index](README.md) · [Home](../README.md)
