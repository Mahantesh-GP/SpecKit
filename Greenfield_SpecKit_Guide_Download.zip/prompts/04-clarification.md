# Clarification — proposed reusable Copilot prompt

> **Status:** Recommended adaptation; not a verbatim executed pilot prompt. Replace placeholders.

```text
Review the current feature spec for missing decisions. Group ambiguities by user behavior, validation, data, access, failure cases and acceptance. For each, provide exact spec reference, question, options with tradeoffs, recommended owner, and whether implementation is blocked. Do not silently choose an answer. Use /speckit.clarify where supported after owner review.
```

**Reference:** [Master Evidence](../evidence/SpecKit_Pilots_Master_Evidence_2026-10-28.md) for observed Spec Kit stages and limitations; [source map](../SOURCE-MAP.md) for guidance provenance.

[Prompt index](README.md) · [Home](../README.md)
