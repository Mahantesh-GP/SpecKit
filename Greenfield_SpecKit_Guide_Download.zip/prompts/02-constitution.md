# Constitution context — proposed reusable Copilot prompt

> **Status:** Recommended adaptation; not a verbatim executed pilot prompt. Replace placeholders.

```text
Prepare input for /speckit.constitution for a GREENFIELD project. Use only explicitly confirmed project decisions and referenced standards. Organize into purpose/scope, architecture/stack, security/data, quality/testing, and review/governance. Separate CONFIRMED, PROPOSED and UNDECIDED. Ask for missing owners or standards; do not manufacture enterprise policy. Draft candidate rules for architect review; do not claim they are approved or edit files without authorization.
```

**Reference:** [Master Evidence](../evidence/SpecKit_Pilots_Master_Evidence_2026-10-28.md) for observed Spec Kit stages and limitations; [source map](../SOURCE-MAP.md) for guidance provenance.

[Prompt index](README.md) · [Home](../README.md)
