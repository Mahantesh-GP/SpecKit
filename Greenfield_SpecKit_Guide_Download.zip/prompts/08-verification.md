# Verification evidence — proposed reusable Copilot prompt

> **Status:** Recommended adaptation; not a verbatim executed pilot prompt. Replace placeholders.

```text
Using supplied build/test output, acceptance evidence and PR diff, create a factual verification report: commands actually run, observed pass/fail counts, manual scenarios, security/config checks, linked work items, unresolved defects and reviewer decisions. Mark missing proof as NOT VERIFIED. Do not infer test results from checked tasks or from AI analysis.
```

**Reference:** [Master Evidence](../evidence/SpecKit_Pilots_Master_Evidence_2026-10-28.md) for observed Spec Kit stages and limitations; [source map](../SOURCE-MAP.md) for guidance provenance.

[Prompt index](README.md) · [Home](../README.md)
