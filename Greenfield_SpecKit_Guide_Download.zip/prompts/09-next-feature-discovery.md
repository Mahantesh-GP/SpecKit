# Next-feature discovery — proposed reusable Copilot prompt

> **Status:** Recommended adaptation; not a verbatim executed pilot prompt. Replace placeholders.

```text
Read-only discovery for a new feature in a repository with existing features. Inspect approved specs, contracts, code and tests in the bounded area [SCOPE]. Identify prior-feature dependencies, callers/consumers, shared models, affected acceptance scenarios and regression tests. Return a matrix: prior feature, exact file/symbol evidence, impact, confidence, action/owner, test. Distinguish verified findings from hypotheses. No file edits, no Spec Kit commands, no ADO changes.
```

**Reference:** [Master Evidence](../evidence/SpecKit_Pilots_Master_Evidence_2026-10-28.md) for observed Spec Kit stages and limitations; [source map](../SOURCE-MAP.md) for guidance provenance.

[Prompt index](README.md) · [Home](../README.md)
