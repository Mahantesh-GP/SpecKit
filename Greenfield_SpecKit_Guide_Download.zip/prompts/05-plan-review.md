# Plan review — proposed reusable Copilot prompt

> **Status:** Recommended adaptation; not a verbatim executed pilot prompt. Replace placeholders.

```text
Read the approved spec, reviewed Constitution and proposed plan. Check that component boundaries, API/data contracts, authentication, error behavior, tests, dependencies and deployment assumptions are supported. Produce a matrix: requirement, planned component, evidence/path, unresolved decision, reviewer. Do not edit code or claim architect approval.
```

**Reference:** [Master Evidence](../evidence/SpecKit_Pilots_Master_Evidence_2026-10-28.md) for observed Spec Kit stages and limitations; [source map](../SOURCE-MAP.md) for guidance provenance.

[Prompt index](README.md) · [Home](../README.md)
