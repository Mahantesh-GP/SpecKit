# Tasks review — proposed reusable Copilot prompt

> **Status:** Recommended adaptation; not a verbatim executed pilot prompt. Replace placeholders.

```text
Review spec, plan and tasks for a greenfield feature. Map every acceptance criterion to implementable tasks and explicit tests. Identify task ordering, dependencies, missing negative cases, security/configuration work and out-of-scope tasks. Report gaps with artifact references; do not fabricate ADO IDs or mark tasks complete.
```

**Reference:** [Master Evidence](../evidence/SpecKit_Pilots_Master_Evidence_2026-10-28.md) for observed Spec Kit stages and limitations; [source map](../SOURCE-MAP.md) for guidance provenance.

[Prompt index](README.md) · [Home](../README.md)
