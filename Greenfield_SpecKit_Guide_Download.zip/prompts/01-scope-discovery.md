# Scope discovery — proposed reusable Copilot prompt

> **Status:** Recommended adaptation; not a verbatim executed pilot prompt. Replace placeholders.

```text
Act as a product analyst for a NEW application. Work in read-only mode. Use only the approved problem statement and supplied requirements. Identify target users, desired outcomes, bounded first feature, in/out scope, measurable acceptance examples, external dependencies, and unanswered decisions. For each point label CONFIRMED or ASSUMPTION and name the evidence or owner. Do not create code, edit files, select a stack or invent approval. Output: scope summary, acceptance examples, open-question table, suggested first slice.
```

**Reference:** [Master Evidence](../evidence/SpecKit_Pilots_Master_Evidence_2026-10-28.md) for observed Spec Kit stages and limitations; [source map](../SOURCE-MAP.md) for guidance provenance.

[Prompt index](README.md) · [Home](../README.md)
