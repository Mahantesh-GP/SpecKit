# 04 · Plan and Tasks

**Problem:** A valid feature description does not tell developers how to implement it safely.

**Fix:** Run `/speckit.plan` for a proposed technical design and `/speckit.tasks` for ordered, reviewable work.

1. Review plan for stack, components, data/API contracts, security, test approach and deployment assumptions.
2. Flag architecture decisions needing owner/architect approval.
3. Review tasks for dependencies, acceptance criteria, test work and manageable boundaries.
4. Map tasks to ADO only through your team's established process; generated IDs are not automatically real work items.

**Copy/paste:** [Plan review prompt](../prompts/05-plan-review.md) and [Tasks review prompt](../prompts/06-tasks-review.md).

**Output:** approved-enough technical direction and actionable tasks; approval remains a human process.

[Next: Analyze and Implement](05-analyze-implement.md) · [Home](../README.md)
