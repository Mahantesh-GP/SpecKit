# 05 · Analyze and Implement

**Problem:** Requirements, design and tasks can disagree; checked tasks alone do not prove working code.

**Fix:** Use `/speckit.analyze` to inspect cross-artifact consistency, resolve significant findings, then use `/speckit.implement` where supported with normal developer review.

1. Check requirement-to-task coverage, contract alignment, scope drift and unresolved decisions.
2. Correct the source artifacts and rerun relevant checks as necessary.
3. Implement in reviewable changes; inspect generated code and dependency changes.
4. Execute actual builds and tests; record commands and outputs, not only AI summaries.

**Copy/paste:** [Analyze review prompt](../prompts/07-analyze-review.md).

**Evidence boundary:** For Flask Todo List UX the evidence register reports **16/16 requirement-to-task mapping**; that is not 16 tests, and it must not be presented as the separate .NET Todo greenfield result. `Converge` was not recorded for that Todo UX feature.

[Next: Verification](06-verification-handoff.md) · [Home](../README.md)
