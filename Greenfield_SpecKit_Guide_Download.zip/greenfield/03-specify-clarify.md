# 03 · Specify and Clarify

**Problem:** A broad request leads to a plausible but untestable specification.

**Fix:** Use `/speckit.specify` to document *what* users need and acceptance scenarios, then `/speckit.clarify` to resolve material ambiguity before design.

1. Provide approved feature scope, user roles, outcomes and concrete acceptance examples.
2. Inspect `spec.md` for missing edge cases, ambiguous terms and unapproved assumptions.
3. Run `/speckit.clarify` where available; record questions, answers, decision owner and unresolved items.
4. Do not let an AI response silently become a product decision.

**Copy/paste:** [Specification prompt](../prompts/03-specification.md) and [Clarification prompt](../prompts/04-clarification.md).

**Output:** reviewed, testable feature requirements and a visible decision record. **Evidence boundary:** Master Evidence reports Specify/Clarify in Todo feature work but lacks the complete original greenfield .NET Todo prompt/answer transcript.

[Next: Plan and Tasks](04-plan-tasks.md) · [Home](../README.md)
