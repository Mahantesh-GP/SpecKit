# 06 · Verification and handoff

**Problem:** Finished Spec Kit artifacts are not proof that the application behaves correctly.

**Fix (recommended):** Demonstrate working behavior and retain verifiable evidence.

- Run build, automated tests and appropriate security/static checks; record exact commands, outcomes and failures.
- Validate acceptance scenarios and negative/edge cases; distinguish manual demonstration from automated coverage.
- Review diffs, configuration and secret handling before PR.
- Link approved work items, code changes, tests and reviewer decisions according to team process.
- Record known gaps and deferred work rather than asserting production readiness.

**Copy/paste:** [Verification evidence prompt](../prompts/08-verification.md).

**Evidence boundary:** Master Evidence documents pilot-specific outcomes across *different* applications. It does **not** establish a complete greenfield .NET Todo CI run or production release.

[Next: Subsequent features](07-subsequent-features.md) · [Home](../README.md)
