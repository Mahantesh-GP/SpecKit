# 01 · Scope and readiness

**Problem:** A greenfield team may have a product idea but no agreed first increment.

**Fix (recommended):** Identify users, business outcome, first feature boundary, acceptance examples, known constraints, dependencies and decisions requiring approval. Do not confuse product discovery with implementation.

1. Confirm an authorized feature owner and a small, testable first slice.
2. Capture in-scope / out-of-scope behavior and acceptance examples.
3. Record unknowns; do not invent architecture or organization policy.
4. Confirm repository, tools, access and Spec Kit installation before commands.

**Copy/paste:** [Greenfield scope discovery prompt](../prompts/01-scope-discovery.md).

**Ready when:** owner can describe the outcome and approve a bounded first feature. **Source:** recommended practice; Master Evidence only establishes an earlier separate .NET/React/SQL Server Todo pilot, not its complete discovery transcript.

[Next: Constitution](02-constitution.md) · [Home](../README.md)
