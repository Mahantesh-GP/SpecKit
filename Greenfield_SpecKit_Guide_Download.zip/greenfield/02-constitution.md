# 02 · Constitution

**Problem:** Without project-wide rules, generated plans may disagree about stack, architecture, security or testing.

**Fix (recommended):** Run `/speckit.constitution` with **confirmed** project constraints, marking undecided items as questions. Unlike Brownfield, there is no existing implementation whose patterns must be inferred.

1. Gather approved technology, architectural principles, security/data boundaries, testing expectations and review ownership.
2. Use [Constitution prompt](../prompts/02-constitution.md) with `/speckit.constitution` where supported.
3. Review generated rules with the project lead/architect. Separate actual decisions from examples.
4. Do not claim the Constitution is enterprise policy unless ratified.

**Output:** reviewed project Constitution; open decisions clearly identified. **Evidence:** Master Evidence records Constitution artifacts for Todo feature work, but exact rules for the separate greenfield .NET Todo track are not fully reconciled.

[Next: Specify and Clarify](03-specify-clarify.md) · [Home](../README.md)
