# 07 · Subsequent features

**Problem:** A greenfield app becomes an existing system after the first feature; later work can affect prior behavior.

**Fix (recommended):** Reuse the reviewed Constitution, inspect current specs/contracts/code, identify previous-feature dependencies, and establish regression evidence before implementing the next feature.

1. Select an approved feature; identify existing components and consumers.
2. Use [Read-only dependency prompt](../prompts/09-next-feature-discovery.md) before `/speckit.specify`.
3. Follow Specify → Clarify → Plan → Tasks → Analyze → Implement and run relevant regressions.
4. If changing an existing approved feature, follow the [Brownfield specification evolution guidance](../README.md) only after adding the Brownfield guide to the same repository; this package deliberately contains **no broken cross-package link**.

**Evidence:** Master Evidence records multiple subsequent Flask Todo features, including feature 004 depending on feature 003; these are **Brownfield Todo** observations, not evidence that the separate greenfield .NET Todo pilot had the same dependencies.

[Home](../README.md)
