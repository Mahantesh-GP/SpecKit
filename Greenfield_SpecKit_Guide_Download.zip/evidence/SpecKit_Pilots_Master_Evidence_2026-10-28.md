# GitHub Spec Kit — Master Pilot Evidence Reference

**Version:** 1.0 · **Compiled:** 28 October 2026  
**Purpose:** Preserve the *observed* Spec Kit work from Todo and Adaptive Workflow / DocNav as a factual reference for later developer guides. **This is not a developer guide, PPT, approval record, or claim of production readiness.**

## Evidence handling rules

- **Recorded** = described in earlier screenshot-based evidence register or project guide; **reported** = stated in pilot notes without independently available raw logs; **pending** = not demonstrated. The original screenshots are not embedded in this file.
- Preserve each project's technology, scope and results. Do not combine the Flask Todo experiment with the earlier .NET/React/SQL Server Todo pilot.
- Later 28-Oct runtime evidence **supersedes** the older DocNav status that application-level submission had not succeeded.
- Spec Kit artifact completion and Analyze/Converge findings are **not** substitutes for business approval, runtime tests, regression coverage or code review.
- Keep unapproved experiments, untested tools, and suggested operating practices clearly labeled.

## Project index

| Track | Application | What was done | Evidence boundary |
|---|---|---|---|
| Todo feature work | Python / Flask / Jinja2 / SQLite / pytest Todo | Feature lifecycle and subsequent Todo feature work; screenshot-based artifacts and ADO links | Do not infer production release or exhaustive tests |
| Todo brownfield discovery | Same Flask Todo, separate **Repomix** and AMD-001 exercises | Scoped context pack; baseline tests; proposed pagination amendment | Repomix is a tested *optional* tool; amendment not approved/implemented |
| Separate Todo SDD sample | .NET 8 / React / SQL Server Todo | Earlier end-to-end Spec Kit / ADO experiment | Keep distinct; exact screenshot-to-feature correspondence not reverified here |
| Adaptive Workflow / DocNav | Existing multi-project .NET / Azure Durable Functions solution | Reference single-PDF DocNav submission feature in `WorkflowActivities` | Successful activity-level HTTP 202; not production Commitment Typing |

---

# A. Todo — screenshot-derived feature evidence

## A1. Technology and scope

The Todo feature evidence recovered from the 28-Oct discussion identifies a **Python/Flask/Jinja2/SQLite/pytest** application. Earlier work also involved a **separate .NET 8 + React + SQL Server Todo sample**. Treat these as separate tracks until the exact original image/file IDs are reconciled.

Recorded subsequent Todo feature areas:

1. Todo Expiration.
2. Lifecycle Operations.
3. List UX Improvement / Pagination.
4. Due Date Tracking.

**ADO:** Todo List UX / Pagination was associated in the screenshot review with story **904672**. Earlier sample notes also reference story **900330**; do not silently assign it to the same feature.

## A2. Spec Kit lifecycle evidence

| Stage | Recovered observation | What can be said safely | Missing precision |
|---|---|---|---|
| Constitution | Project engineering rules shown in screenshots | Constitution was used to set project-level constraints | Exact rule text and image-to-version mapping need original images |
| Specify | Requirements and acceptance scenarios for Todo feature(s) | Feature intent was documented before implementation | Full requirement IDs/wording per feature |
| Clarify | Clarification step part of documented workflow | Ambiguities were considered where applicable | Exact question/answer list not revalidated |
| Plan | Technical approach grounded in Flask app | Design was captured before task breakdown | Exact plan version and file paths |
| Tasks | Implementation tasks and dependencies | Feature work was broken into reviewable steps | Full task-to-commit mapping |
| Analyze | Consistency review; for Todo UX reported **16/16** requirement-to-task mapping | Traceability check was reported | This is **not** 16 tests or test coverage |
| Implement | Screenshots of implementation artifacts and checked tasks | Work was recorded as implemented in the feature evidence | Git diff, CI/PR and exact release state |
| Converge | Not recorded as run for Todo UX | Do not claim Converge for this Todo feature | — |

## A3. Flask Todo pagination and proposed change

**Existing behavior:** Pagination feature `003` used `PAGE_SIZE = 10`. A subsequent proposed amendment **AMD-001** would add selectable page sizes **10 / 20 / 50**, with default 10. Feature `004` has a dependency on feature `003`.

**Status:** AMD-001 was a **specification experiment only**, without an approved ADO story/approver and without implemented or validated selector behavior. It highlighted the need to reconcile `spec.md` with plans, tasks, contracts, tests and dependent features when requirements evolve. Do not call the amendment approved or delivered.

**Tests:** **27 existing baseline tests passed** in the documented experiment. These tests establish a baseline only, **not** validation of AMD-001.

## A4. Repomix experiment — actual observed results

**Purpose:** Explore whether packaging a *selected* set of existing source files could help brownfield discovery. Repomix is not a Spec Kit command and is not a prerequisite.

| Item | Recorded result |
|---|---|
| Tool | Repomix **v1.18.1** |
| Output | `todo-context.md` |
| Included application files | **5** |
| Estimated packed context | **~2,249 tokens** |
| Packed characters | **9,291** |
| Files | `app/routes.py`, `app/db.py`, `app/__init__.py`, `app/schema.sql`, `app/templates/index.html` |
| Security scan | No suspicious files reported *in that run*; not security certification |
| Requested but absent | `tests/**` and `README.md` |
| Why absent | **Not established** |

Recorded command (validate syntax/version in the actual environment before reuse):

```powershell
npx repomix@latest . --include "app/**,tests/**,README.md" --ignore "**/.venv/**,**/__pycache__/**,**/*.pyc,**/.env*,**/app.db,**/*.pfx,**/*.pem" --style markdown --output todo-context.md --token-count-tree
```

**What this proves:** a Markdown snapshot of five source files and an estimated size were produced. **What it does not prove:** reduced Copilot token charges, better answer accuracy, saved time, full test inclusion, or suitability for all enterprise repositories. Other community extensions listed in older guides were **not tested** in these pilots; do not recommend them as if validated.

---

# B. Adaptive Workflow / DocNav — screenshot-derived brownfield evidence

## B1. System boundaries (essential)

- **`AdaptiveWorkflowEngine`**: existing multi-project Azure Durable Functions orchestration solution/repository.
- **`WorkflowActivities`**: **project inside that solution**, where the reference feature was added; **not** a standalone repository.
- **Commitment Typing**: consuming team and business use case; business logic not implemented by this reference pilot.
- **DocNav**: separate external document processing service/API; not a project inside the workflow solution.
- **Satish's technical walkthrough**: primary architecture reference for framework responsibilities.

Baseline execution model:

```text
HTTP request
  → HttpStartOrchestrator
  → WorkflowDefinitionProvider (base workflow + variant overlay)
  → ProcessOrchestrator
  → ActivityRegistry → WorkflowActivities
  → external service as needed (DocNav)
```

Existing orchestration and registration patterns were to be preserved; the pilot did **not** redesign the orchestrator or implement DocNav's OCR/callback internals.

## B2. Feature boundary

**Feature/branch:** `001-docnav-job-submission`  
**Objective:** From a workflow activity, obtain one PDF referenced in Azure Blob Storage and submit it to DocNav DEV API; carry correlation context and report the submission response/failure.

**Inputs documented:** required `documentReference`; optional `configurationId` and `sourceMetadata`; existing workflow correlation/step/instance identifiers where available.

**User stories:** P1 successful submission, P2 Blob retrieval failure, P3 DocNav rejection. **Requirements:** FR-001–FR-014. **Success criteria:** SC-001–SC-004. These are documented artifact targets, not automatically measured outcomes.

## B3. Actual screenshot inventory — 28 October

| Evidence ID | Screenshot group | What it establishes | Limit |
|---|---|---|---|
| S01 | **3** `constitution.md` screenshots | **9** engineering principles; version footer v1.0.0 dated Sep 29; architecture and quality guardrails | Not proof of enterprise ratification |
| S02 | **6** `spec.md` screenshots | Feature scope, three priority stories, FR-001–FR-014, SC-001–SC-004 | Requirements, not execution results |
| S03 | **5** `plan.md` screenshots | .NET 10 `WorkflowActivities` design, interfaces, DI, HttpClient/multipart, correlation, existing orchestration preserved | At planning time no automated test project; manual verification is not test coverage |
| S04 | **8** `tasks.md` screenshots | T001–T028; phases, error handling, URL normalization, logging and redaction | Checked tasks are artifact status; exact diff/commit pending |
| S05 | Analyze / Implement / Converge screenshots | Findings addressed; final Converge no remaining in-scope findings | Static consistency check, not production validation |
| S06 | Later Aspire/runtime screenshots and user correction | Azure CLI credentials and Blob URL fixed; **DocNav HTTP 202 Accepted with request ID through demonstrated activity flow** | Does not prove OCR completion, callback handling or deployment |
| S07 | Solution Explorer screenshot | Multi-project `AdaptiveWorkflowEngine`, with `WorkflowActivities` as one project | Do not mislabel as independent application |

## B4. Lifecycle — what happened and why it mattered

| Step | Recorded use | Review / evidence interpretation |
|---|---|---|
| `/speckit.constitution` | Project guardrails and architecture boundaries | Review principles against existing solution; do not invent organization-wide policy |
| `/speckit.specify` | Bounded single-PDF submission and error stories | Keep scope out of Commitment Typing business rules |
| `/speckit.clarify` | Resolved questions such as optional `configurationId`; discussed retry/idempotency | Clarification is not architect approval; retry policy final approval not evidenced |
| `/speckit.plan` | Activity, interfaces, Blob source, DocNav service, token provider, DI, correlation | Respect existing architecture; test-project absence recorded |
| `/speckit.tasks` | T001–T028, including security/redaction tasks T026–T028 | Task status alone not code review proof |
| `/speckit.analyze` | Cross-artifact consistency issues found/reviewed | Human resolution required |
| `/speckit.implement` | Reference activity and supporting components | Validate through source diff, build and runtime |
| `/speckit.converge` | Final no in-scope findings in pilot | Pilot-specific command; availability varies; not a runtime test |

**Implementation inventory reported** (exact paths/commit need source diff): `SubmitDocNavJobActivity`, `IBlobDocumentSource`/`BlobDocumentSource`, `IDocNavJobSubmissionService`/`DocNavJobSubmissionService`, `IDocNavAccessTokenProvider`, `DocNavServiceOptions`, input/result models, dependency injection and registration.

**Build:** Pilot recorded **zero errors and zero warnings**. This is a build result, not a guarantee of complete functional or regression coverage.

## B5. Runtime sequence and corrections

1. Local HTTP/Durable execution reached the `SubmitDocNavJob` activity.
2. Blob access and DocNav configuration/authentication/multipart behavior were investigated; earlier errors included 401 and 415.
3. A separate Postman call returned **202 Accepted** and a request ID; status was also checked separately.
4. **Later evidence on 28 Oct:** Azure CLI credentials and Blob URL were corrected, and the **actual activity-level submission received HTTP 202 Accepted and a request ID**.
5. Thus earlier descriptions saying activity-level acceptance was unverified are **historical**, not the current state. Do **not** extrapolate to downstream OCR, callback completion, full business workflow or production deployment.

**Meaningful clarification:** Should a repeated idempotency key create a new DocNav job or reuse a prior result? The pilot considered caller/orchestrator responsibility versus persistent deduplication. **No final authorized decision is evidenced**; retain as an open governance/design point.

## B6. Outstanding evidence / claims not to make

- No confirmed Git diff/commit/PR ID or complete raw source snapshot in this master.
- No demonstrated complete automated regression suite for the new activity; at planning time there was no automated test project.
- No verified production deployment, completed Commitment Typing business feature, downstream OCR/callback lifecycle or formal architect/PO approval of retry/idempotency.
- No measured productivity, token savings, cost reduction, or enterprise adoption result.
- Redact secrets, bearer tokens, subscription keys, signed Blob URLs and customer documents before publishing screenshots.

---

# C. Evidence-to-guide reuse map (future work only)

| Question a developer will ask | Actual evidence to reference | What to avoid |
|---|---|---|
| How do I start in an existing multi-project solution? | Adaptive Workflow solution explorer + bounded `WorkflowActivities` feature | Initializing every `.csproj` or redesigning framework |
| What does Spec Kit produce? | Constitution/spec/plan/tasks screenshots and actual commands | Treating generated text as approved |
| Why clarify before implementing? | `configurationId` optionality; idempotency decision | Inventing resolved decisions |
| Why inspect tests first? | Flask Todo 27-test baseline; Adaptive Workflow test-project gap | Calling 27 tests proof of new feature behavior |
| Is Repomix required? | Five-file / ~2,249-token optional experiment | Listing untested extensions as EA-tested tools |
| How do we prove an integration worked? | Adaptive Workflow activity HTTP 202/request ID | Claiming OCR/callback/production completion |
| What if a spec changes later? | Todo `003` / AMD-001 and dependency on `004` | Calling an experimental spec edit an approved delivery |

## Master source register

1. `Adaptive_Workflow_Phase1_Evidence_Register.md` — screenshot count, evidence IDs S01–S07, updated 28-Oct runtime correction.
2. `Adaptive_Workflow_DocNav_SpecKit_Brownfield_Master_Context.md` — original architecture and pilot narrative; **its earlier activity-level status is superseded by the 28-Oct addendum**.
3. Uploaded Brownfield `developer-guide.md` — Repomix experiment, Todo 003/AMD-001, 27-test baseline, limitations; this document includes optional community tool research **not validated in the pilots**.
4. Earlier Todo screenshot-review conversation and feature evidence — four feature areas, story 904672, reported 16/16 traceability; original screenshots and full command transcript should be cross-indexed before external publication.

## Follow-up verification fields (not yet supplied)

| Item | Status |
|---|---|
| Exact original screenshot filenames / hashes / image captions for Todo | Pending |
| Exact screenshot filenames / hashes for Adaptive Workflow S01–S07 | Pending |
| Full text of each Todo feature constitution/spec/plan/tasks | Pending cross-check |
| ADO story IDs, PR links, commit hashes and reviewers per feature | Pending |
| Build/test commands and timestamps tied to commits | Pending |
| Redacted DocNav HTTP 202 activity log / request ID screenshot | Reported seen; reusable artifact to attach |

**Master-file maintenance rule:** Append a dated correction with its evidence; do not silently overwrite prior observations or promote a proposal into a validated result.

---
## Evidence addendum — 28 Oct 2026: Repomix discovery of WorkflowActivities before Constitution

**Evidence source:** Five user-supplied VS Code screenshots, saved alongside this master reference as `image-1793198575213.jpg`, `image-1793198595051.jpg`, `image-1793198605908.jpg`, `image-1793198611389.jpg`, `image-1793198616753.jpg` (image names are local evidence identifiers, not Git repository paths).

**Why this was done:** When introducing Spec Kit for the first time into the existing AdaptiveWorkflowEngine solution, the developer wanted to discover relevant `WorkflowActivities` project context *before* drafting `/speckit.constitution`. The goal was to select useful code rather than supply the whole multi-project solution or unwanted generated files to the LLM. This is a real experiment, not a claim that Repomix is mandatory for Spec Kit.

**Observed execution:** In a PowerShell terminal at a `.../AdaptiveWorkflowEngine/WorkflowActivities` working directory, the developer ran `npx repomix@latest` (Repomix reported version **1.18.1**). The command included `--include "Contracts/**,Services/**"`, an `--ignore` list covering generated/irrelevant content (visible examples include `**/.specify/**`, `**/__pycache__/**`, `**/*.json`, `**/*.md`, `**/app.db`, `**/*.pptx`, `**/bin`), `--style markdown`, `--output workflowActivity.md`, and `--token-count-tree`. The full wrapped ignore argument is partially obscured in the photograph; copy/verify the exact command from the terminal before publishing it as a paste-ready command.

**Observed results:** Terminal stated `Packing completed successfully!`. The generated `workflowActivity.md` contains a Repomix explanation, directory structure and selected source-file contents, with a read-only warning. Pack summary: **13 files, 7,017 tokens, 34,840 characters**; security check: **No suspicious files detected** (not a comprehensive secret audit). The token tree includes `Contracts/IWorkflowActivities.cs` (185 tokens), `Services/ServiceImplementation.cs` (909), and `Services/DocNavJobSubmission/` (5,129). Top file counts: `DocNavJobSubmissionService.cs` 1,383; `SubmitDocNavJobActivity.cs` 1,249; `ServiceImplementation.cs` 909; `BlobDocumentSource.cs` 649; `DocNavJobSubmissionStubService.cs` 627. The visible directory also contains Blob and DocNav service interfaces, token provider interface/stub, models and options.

**Scope caveat:** This is a **selected WorkflowActivities source-code subset**, not a complete map of the AdaptiveWorkflowEngine architecture. The output visibly includes DocNav implementation code, so this screenshot records a Repomix run on the code state shown; it does not independently establish that the same exact file set existed before the *original* constitution was created. The user's stated intended use is *pre-Constitution discovery*.

**Recommended evidence-based guide step:** Before first `/speckit.constitution`, identify the relevant project and its source folders; optionally run Repomix on approved, relevant source files; inspect the generated Markdown for scope, completeness, sensitive data and misleading omissions; use it as one context input alongside architecture docs and team standards; have developers/architects review the constitution. Repomix does not automatically derive or approve engineering rules.

**Not demonstrated by these screenshots:** Copilot consuming `workflowActivity.md`, the exact prompt used for constitution, any measured token savings versus another method, or improved output quality. These require separate evidence.

---
## Explanation addendum — 28 Oct 2026: What Repomix is, why we used it, and how it differs from GitHub Copilot

### What is Repomix?

Repomix is a **repository-packaging tool**. It reads selected local repository files and produces a structured, AI-readable output (in our experiment, a Markdown file). It can include file paths, a directory tree, file contents, and estimated token counts. **It is not an LLM, does not itself reason about architecture, and does not create or approve a Spec Kit constitution.**

### Why use it before Constitution in a large, multi-module Brownfield solution?

The first constitution should reflect **existing** architecture, contracts, conventions, security requirements and project rules—not invented standards. In a large solution, blindly giving an AI assistant every file can introduce irrelevant code, generated artifacts, excessive context and unnecessary exploration. Repomix lets the developer choose a **focused snapshot** for AI analysis. This is an **optional preparation step**, not a prerequisite imposed by Spec Kit.

A locally run Repomix packing command does **not call an LLM to analyze the repository**, so creating the packed file itself does not consume LLM inference tokens. The resulting file **does consume model context/tokens when supplied to GitHub Copilot or another LLM**. Focused packing *may* reduce repeated AI-driven file discovery and unnecessary context, but **we have not measured any overall token, cost or time savings** in this pilot. The output token count is an estimate of packed content size, **not a savings metric**.

### How it helped in our actual WorkflowActivities experiment

- **Real scope:** `WorkflowActivities` project **inside** the existing multi-project `AdaptiveWorkflowEngine` solution; not the whole solution.
- **Selection:** Included `Contracts/**` and `Services/**`, with an ignore list for unwanted file types and generated artifacts.
- **Observed tool:** `npx repomix@latest`, reporting Repomix **v1.18.1**.
- **Observed artifact:** `workflowActivity.md`, a single Markdown representation with directory structure, source-file paths and selected C# contents.
- **Observed size:** **13 files, 7,017 estimated tokens, 34,840 characters**. Packing succeeded; the tool reported no suspicious files detected (not proof of a full security audit).
- **Practical value:** The developer obtained a portable, reviewable subset of the activity's contracts, DocNav submission services, interfaces, options, models and Blob access code. This can serve as focused input for understanding the module and drafting **proposed** constitution rules.
- **Evidence boundary:** Screenshots prove successful packing and visible content. They do **not** prove Copilot subsequently used this exact output for `/speckit.constitution`, that constitution quality improved, or that total token usage fell. The screenshot contains already-existing DocNav code; therefore it does not establish the exact source state at the original first Constitution run.

### GitHub Copilot versus Repomix

| Question | GitHub Copilot (GHCP) | Repomix |
|---|---|---|
| Primary job | AI assistant that can inspect code, answer questions, reason about patterns and help draft a constitution | Local utility to package a selected repository snapshot for later inspection or AI input |
| Discovers/explains architecture? | Can analyze accessible files and explain patterns, subject to context and accuracy limits | **No reasoning**: records paths and content; an engineer or LLM interprets them |
| File selection | Can search/read workspace files through available tools and context | Developer explicitly controls inclusion and exclusion patterns |
| LLM tokens during preparation | AI exploration and analysis use model context/tokens | Local packing itself uses **no LLM inference tokens** |
| Tokens when AI analyzes output | Uses tokens for whatever content GHCP reads | Packed Markdown **still uses tokens** when GHCP reads it |
| Creates constitution? | Can draft via Spec Kit prompts using available evidence | **No**; only prepares possible source context |
| Currentness | May inspect current workspace state when tools permit | Snapshot becomes stale as soon as repository files change; regenerate when needed |
| Risk | May overlook files or infer unsupported conventions | May omit important modules or include sensitive content; review scope and security |

**Complementary workflow, not a replacement:** Developer selects the correct solution/module boundary → optionally packages approved relevant files with Repomix → reviews the Markdown and adds missing architecture docs/test policies → gives the context to GHCP → uses `/speckit.constitution` to propose rules → developer/architect checks and approves those rules. For a solution-wide constitution, a WorkflowActivities-only package is **insufficient** by itself; include relevant orchestrator, shared contract, workflow definition, testing and governance context as appropriate.

### Language safe to reuse in the future developer guide

> **Optional — prepare repository context before Constitution.** In a large existing solution, use Repomix to package only the relevant source folders into a Markdown snapshot. Repomix runs locally without LLM inference during packaging. Review the output for completeness and sensitive information, then provide it to GitHub Copilot as supporting context when drafting the Spec Kit constitution. In our `WorkflowActivities` experiment, this produced a 13-file, 7,017-token Markdown snapshot. We have **not** measured net token savings or verified that this particular snapshot was used in the original Constitution prompt.

**Screenshot provenance:** See the immediately preceding Repomix evidence addendum for five image identifiers and observed command/output details. This explanation is a combination of those screenshot observations and general tool-behavior interpretation, explicitly separated above.

---

## Brownfield Constitution — corrected pre-discovery workflow and reusable prompt (28 October 2026)

**Status:** Recommended developer guidance, not evidence that the exact prompt below was run in the original pilot. The Repomix package generation itself is evidenced by screenshots.

### Why discovery comes before Constitution

A Brownfield Constitution should reflect established, reusable engineering guardrails, not invented rules or one-off feature requirements. Before running `/speckit.constitution`, the developer must gather and verify the existing project's technology, architecture, security, quality and governance context.

**Two supported discovery routes:**

1. **Repomix:** Locally package explicitly selected relevant source files into a structured Markdown snapshot. No LLM inference tokens are used to *create* the package. The resulting source snapshot is not itself an architectural interpretation; an LLM will consume context tokens when reading it.
2. **GitHub Copilot (GHCP):** Inspect the workspace and relevant project documents, then ask GHCP to prepare a reviewed project-discovery report. GHCP uses model context/tokens for analysis.

Both routes can provide input context for `/speckit.constitution`; neither replaces developer verification. Review completeness, sensitive content, existing test/CI configuration and authoritative architecture decisions. A module-only package is not sufficient evidence for solution-wide rules.

**Our observed example:** Repomix v1.18.1 successfully packed 13 selected files under `WorkflowActivities` into `workflowActivity.md` (7,017 estimated output tokens). Screenshots do **not** establish that this exact file was subsequently used in the original Constitution invocation, nor measured net token savings.

### Reusable GHCP prompt — draft a Brownfield Constitution

Replace the placeholders with the actual, reviewed file paths. Use the installed Spec Kit command spelling in your environment.

```text
/speckit.constitution

We are introducing GitHub Spec Kit into an existing Brownfield application.

Before drafting the Constitution, review the verified repository context provided:
- Repomix package: [path/to/reviewed-package.md]
  OR
- GitHub Copilot project-discovery report: [path/to/reviewed-discovery-report.md]

Also consult available authoritative architecture documents, build and test
configuration, and existing engineering standards relevant to the scope.

Identify and distinguish:
1. Existing technology stack and runtime versions.
2. Solution/project structure and module boundaries.
3. Architecture, dependency directions and integration patterns.
4. Authentication, security and secrets-handling practices.
5. Coding conventions and error-handling patterns.
6. Tests, build checks and CI practices actually present.
7. Existing review, approval and change-governance practices.

Draft a repository-level Constitution that:
- Preserves verified existing architecture and engineering practices.
- Defines reusable guardrails for subsequent features, not requirements
  for one specific feature.
- Distinguishes confirmed standards from proposed recommendations.
- Does not invent technologies, coverage percentages, security policies,
  compliance obligations, reviewer roles or approval requirements.
- Cites supporting files or documents for proposed principles where possible.
- Flags missing modules, conflicting evidence and decisions needing human input.

Do not assume the supplied package covers the entire solution.
Present the Constitution as a DRAFT for technical-lead/architect review.
Do not describe it as approved until the responsible owner confirms it.
```

### Review checkpoint before adopting the Constitution

- Confirm whether the Constitution governs the entire solution or a specific workspace/project; expand discovery scope accordingly.
- Check every proposed rule against source files, authoritative documents or explicit team decisions.
- Remove feature-specific acceptance criteria, speculative architectures, invented metrics and unapproved roles.
- Obtain the normal technical review and commit the approved artifact using the team's established process.

**Guidance versus evidence:** The prompt and workflow above are a proposed reusable job aid derived from our Constitution discussion. The screenshots evidence the Repomix packaging output, not execution of this exact prompt or formal approval of the Constitution.

---

## Brownfield Constitution — screenshot-derived general template (28 Oct 2026)

**Source:** User-provided photographs of “SpecKit Adoption Feedback and Recommendations,” section **1.2 General Constitution Template** and continuation. This is a **template/reference**, not a verified `constitution.md` from Adaptive Workflow and not a command prompt. Text cropped at the image edge is deliberately not reconstructed.

```markdown
# Repository Constitution: [Repository Name]
*Status: Active / Governed | Decision Authority: [Named Role/Lead Architect] | Last Ratified: [date — cropped in screenshot]*

## 1. Purpose & Workspace Boundaries
- Governs all features developed within `[repository-root]`.
- Enforces engineering guardrails across all contained projects: `[project paths — screenshot cropped]`.
- Single-feature business requirements are explicitly forbidden in this document.

## 2. Architecture & Technical Stack Guardrails
- **Approved Runtimes:** .NET 8 (C# 12), ASP.NET Core Web APIs. [Illustrative]
- **Dependency Flow:** Domain -> Application -> Infrastructure -> API [remainder cropped; illustrative].
- **Inter-Service Communication:** Asynchronous event-driven messaging via [cropped; illustrative].
- **Contract Policy:** Public API contracts are immutable; breaking changes [remainder cropped; illustrative].

## 3. Security, Authentication & Data Protection
- Endpoints must enforce OAuth2/OIDC JWT bearer validation. [Illustrative]
- Connection strings and secrets must load via Azure Key Vault / Environment [remainder cropped; illustrative].
- Multi-tenant data segregation must filter on `TenantId` at the persistence [remainder cropped; illustrative].

## 4. Quality Minimums & Test Strategy
- Every domain mutation requires corresponding unit tests in `tests/*.UnitTests` [remainder cropped; illustrative].
- Integration tests in `tests/*.IntegrationTests` must pass against Testcontainers [remainder cropped; illustrative].
- Minimum branch coverage requirement: 80% on core business domains. [Illustrative, NOT verified EA policy]

## 5. Review & Change Governance
- Spec Kit analysis findings must be addressed; material contradictions cannot [remainder cropped].
- Amendments to this constitution require a formal PR approved by the Lead Architect [remainder cropped; illustrative].
- Temporary deviations must be documented in the feature `plan.md` with an e[remainder cropped].
```

### How to use this template in Brownfield

1. **Discover before drafting:** inspect the existing repository, using either GHCP discovery or a focused Repomix package plus authoritative docs and configurations.
2. **Use the discovered context** when invoking `/speckit.constitution`; populate the five template sections with **verified, project-specific** facts.
3. **Scrub unsupported assumptions:** the pictured .NET stack, OAuth, Key Vault, Clean Architecture, Testcontainers, `TenantId`, 80% coverage and approval roles are examples, **not** demonstrated Adaptive Workflow requirements.
4. **Review with the authorized technical owner** before treating the Constitution as an adopted project guardrail.

**Evidence status:** Screenshot verifies the *proposed template content* and its five-section organization; it does not prove execution of a particular prompt, adoption of those illustrative rules, or formal sign-off.

---

## Brownfield — First-Feature Readiness and Read-Only Discovery (28 October 2026)

**Status:** Proposed developer guidance, grounded in the user's screenshot of *SpecKit Adoption Feedback and Recommendations* (sections “Brownfield 1st Feature Development & Read-Only Discovery” and “The 7-Step Read-Only Discovery Sequence”). Do not mistake recommendations for steps proven completed in Adaptive Workflow.

### Why select a project with an existing regression suite?

For the first Brownfield Spec Kit pilot, **prefer a project with an existing, runnable regression suite**. Run it **before** changing code and again **after** implementation, adding feature-specific tests as needed. Compare results to detect unintended changes to existing behavior. A regression suite is an important validation aid, not proof of zero defects.

- **Suite exists and passes:** Record the test command, environment, date, test count, pass/fail results; preferred pilot readiness.
- **Suite exists but has failures:** Record pre-existing failures and get the team to agree on a known baseline; do not count pre-existing failures as newly introduced.
- **No suite:** Explicitly declare that no automated regression baseline exists. Document known behavior and establish agreed manual smoke checks and/or targeted automated characterization tests **before** implementation. This is a less suitable first pilot until reliable verification is possible.
- **Tests not executed:** Record “not run,” with the reason; never mark them as passing.

**Decision gate:** The feature owner and technical reviewer agree how existing behavior will be checked after the change. Existing ADO, review, architecture and security controls remain in place.

### Pre-feature read-only discovery — seven steps

This is a **focused, read-only investigation before `/speckit.specify`**; do not reverse-specify the entire repository for one feature.

| # | Activity from screenshot | Practical action | Evidence to record |
|---|---|---|---|
| 1 | Confirm Boundary | Identify the governing solution, targeted project, and relevant shared libraries | Solution/project paths and scope |
| 2 | Locate Entry Points | Follow the relevant API route, handler, or workflow trigger through services to storage/external calls | Current flow and code references |
| 3 | Review Authoritative Documents | Inspect current ADRs, contracts and other authoritative documents; distinguish them from outdated wiki pages | Document links and applicable constraints |
| 4 | Establish Regression Baseline | Run the current test suite for the target area; record command and pass/fail result | Baseline results, including missing/unrun tests |
| 5 | Identify Consumers & Contracts | Check upstream callers, downstream consumers, shared models, schemas, and external APIs | Dependencies and potential impact |
| 6 | Log Gaps and Ambiguities | Record file paths, symbols, uncertainties and questions needing product/technical confirmation | Open questions and owners |
| 7 | Peer Discovery Review | Have a senior developer or technical reviewer confirm findings before `/speckit.specify` | Reviewed discovery summary and go/no-go |

**Output:** A concise first-feature discovery record with scope, current behavior, entry points, dependencies, baseline results, constraints, open questions, and reviewer decision. Use this reviewed record as **context for `/speckit.specify`**. This feature-level discovery is distinct from the earlier repository-wide discovery used to draft `constitution.md`.

### Adaptive Workflow illustration — evidence boundary

For `001-docnav-job-submission`, the relevant scope was `WorkflowActivities` **within** the multi-project `AdaptiveWorkflowEngine` solution; DocNav was a separate external API, and Commitment Typing was a consuming use case. Relevant review topics include the activity contract, Blob document source, DocNav client, failure handling, and runtime verification. The pilot showed a successful build and live DocNav HTTP 202 response, but **does not establish that a full automated regression suite existed or was executed before and after the feature**. Record that distinction in any guide or presentation.

### Recommended first-feature readiness checklist

- [ ] Feature has an approved owner and a bounded objective.
- [ ] Existing regression suite has been run and recorded, **or** the missing-suite baseline and alternative checks are explicitly agreed.
- [ ] Read-only discovery record covers all seven activities above, or marks gaps honestly.
- [ ] Technical reviewer has confirmed the scope, known risks, and validation plan.
- [ ] Only then start `/speckit.specify` with the reviewed discovery context.
