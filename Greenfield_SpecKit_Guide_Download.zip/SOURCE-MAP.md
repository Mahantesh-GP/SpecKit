# Source map and provenance

| Material | Role | Boundaries |
|---|---|---|
| [Master Evidence](evidence/SpecKit_Pilots_Master_Evidence_2026-10-28.md) | **Primary factual source** for pilots and observed stages | Separate .NET Todo, Flask Todo and Adaptive Workflow; do not combine |
| `EA_Spec_Kit_Team_Starter_Job_Aid.docx` (user-provided reference, not bundled) | Secondary style/structure inspiration | Not independent proof that any proposed prompt was executed |
| Existing Brownfield GitHub guide v1.2 | Navigation/prompt-page pattern | Its Brownfield-specific facts do not automatically apply to Greenfield |
| `01-GREENFILED_EXPLORATION.md` (local contextual file, not bundled) | Example of a greenfield *product discovery exercise* | Not evidence of a completed Spec Kit greenfield implementation; intentionally not used as Todo pilot proof |
| This package's `greenfield/` and `prompts/` | **Proposed developer guidance** | Requires project/architect review and real execution evidence |

**No claim:** Greenfield-specific complete transcripts, automated test counts, enterprise policy approval, ADO automation, CI success or production release are not established by the Master Evidence.

[Home](README.md)
