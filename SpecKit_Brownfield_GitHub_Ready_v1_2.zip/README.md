# GitHub Spec Kit — Brownfield Developer Job Aid

> **Status:** EA pilot-informed **draft for review**, not approved enterprise policy. **Scope:** Brownfield first; Greenfield will be added separately.

## The problem

Spec Kit can generate feature artifacts, but an **existing application already has architecture, behavior, contracts, dependencies and tests**. Starting directly with `/speckit.specify` can miss those constraints.

## The fix

**Discover existing facts → review a repository Constitution → establish a regression baseline → investigate the feature and dependencies in read-only mode → use Spec Kit → verify existing behavior.**

This repository is a **developer job aid**, not an installed Copilot skill or an automation that enforces gates. Developers validate generated content; authorized owners approve decisions.

## Choose your next step

| Your situation | Start here |
|---|---|
| We have not adopted Spec Kit in this existing repository | [01 · Project discovery](brownfield/01-project-discovery.md) |
| We understand the repository but need durable engineering rules | [02 · Constitution](brownfield/02-constitution.md) |
| We are selecting our first pilot feature | [03 · First-feature readiness](brownfield/03-first-feature-readiness.md) |
| We need to understand an existing feature before writing its spec | [04 · Read-only feature discovery](brownfield/04-read-only-feature-discovery.md) |
| Our new feature may depend on previous features | [05 · Cross-feature dependencies](brownfield/05-cross-feature-dependencies.md) |
| We are ready to run Spec Kit | [06 · Feature lifecycle](brownfield/06-feature-lifecycle.md) |
| Requirements for an existing feature have changed | [07 · Evolving a specification](brownfield/07-specification-evolution.md) |
| The solution has many projects/modules | [08 · Multi-project boundaries](brownfield/08-multi-project-boundaries.md) |
| We need to know what was *actually* observed | [Pilot evidence and limits](examples/pilot-evidence.md) |

## Brownfield path

```mermaid
flowchart TD
 A[Repository discovery: Copilot or scoped Repomix] --> B[Draft and review Constitution]
 B --> C[Select bounded approved feature]
 C --> D[Run regression baseline or document gap]
 D --> E[Read-only feature discovery]
 E --> F[Cross-feature dependency assessment]
 F --> G[Specify → Clarify → Plan → Tasks → Analyze]
 G --> H[Implement and inspect code]
 H --> I[Run feature tests and regression checks]
 I --> J[PR / QA / owner review and evidence]
```

**Before implementation:** a passing baseline establishes *previous* behavior, not proof that a new feature works. A missing regression suite must be declared, with agreed alternative characterization or smoke checks. A read-only discovery report is not itself an approval.

## Evidence discipline

**Recorded/observed** means supported by the master pilot evidence register; **recommended** means proposed developer practice; **pending** means not demonstrated. Example values in the screenshot-derived Constitution template are *illustrative*, not enterprise standards. See [source mapping](SOURCE-MAP.md).

## Prompt library

Find the right copy/paste prompt and its source in the [stage-by-stage prompt index](prompts/README.md). Discovery prompts are read-only; actual test runs and Spec Kit execution require separate developer action.

## Quick start

1. Open the relevant page above; use the prompt from [`prompts/`](prompts/) only after filling its placeholders.
2. Ask Copilot for file paths and symbols; independently verify the findings in code, contracts and tests.
3. Record the baseline, dependency impact, open questions and reviewer decision.
4. Proceed with the installed Spec Kit commands and normal ADO/PR/QA workflow.

**Do not publish:** bearer tokens, signed Blob URLs, customer documents, subscription keys or private logs.
