# 01 · Discover the existing repository

## The problem
A Brownfield Constitution drafted without reading the actual repository can invent architecture and policies.

## The fix
**Before Constitution**, inspect solution/project structure, runtime/build files, relevant architecture, contracts, tests, CI, security conventions and existing approved standards.

### Two practical context routes
- **GitHub Copilot read-only discovery:** ask for a concise, source-cited repository report; verify it manually.
- **Repomix (optional, tried in the pilots):** package a **scoped** set of selected source files into Markdown, inspect the output, then give the reviewed package as context. Repomix packages source; it does **not** create a semantic architectural explanation by itself.

**Actual Adaptive Workflow Repomix observation:** `WorkflowActivities` subset; 13 files, approximately 7,017 estimated tokens; `workflowActivity.md`. This was *not* the entire multi-project solution and does not prove it was supplied to the original Constitution command.

**Expected output:** repository map, verified constraints, relevant source links, testing/build practices and explicit unknowns.

**Stop/check:** Do not infer solution-wide rules from a `WorkflowActivities`-only package; include the orchestrator and shared contracts if the Constitution governs the full solution.

**Next:** [02 · Constitution](02-constitution.md). See [discovery prompt](../prompts/01-repository-discovery.md).
