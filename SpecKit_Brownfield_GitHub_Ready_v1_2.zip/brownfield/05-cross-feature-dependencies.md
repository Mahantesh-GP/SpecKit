# 05 · Cross-feature dependency assessment

## The problem
A new feature may rely on earlier features, shared code, contracts, data models or workflows. Changing one behavior can affect other consumers.

## The fix
**Before `/speckit.specify`**, run a focused **read-only** dependency assessment. Recheck the findings during `/speckit.plan`, `/speckit.tasks` and `/speckit.analyze`.

Check existing specs **and** current implementation; trace callers and consumers; identify direct/indirect dependencies, in-flight work, shared API/data contracts, owners and regression tests. Classify each finding **confirmed / likely-unverified / unknown** and cite the evidence. Never silently edit another approved feature's baseline.

| Field | Record |
|---|---|
| New feature / story | ID, approved scope and owner |
| Previous feature / consumer | Feature ID, module, interface or external service |
| Dependency evidence | File path, symbol, spec clause, contract or owner confirmation |
| Impact and confidence | Confirmed / likely / unknown |
| Action | Compatibility, clarification, change, test or no action |
| Verification | Relevant regression test and observed/not-run status |

**Pilot example:** Flask Todo feature `004` depends on feature `003` pagination. `AMD-001` proposed page-size selection 10/20/50, default 10, in a **spec-only, unapproved** experiment. The 27 passing baseline tests did not validate that new behavior; downstream impact was not fully reconciled.

**Stop/check:** Escalate materially unknown consumer impacts before implementation. Spec Kit Analyze is a consistency aid, not an exhaustive dependency graph or runtime compatibility proof.

[Copy/paste dependency prompt](../prompts/04-cross-feature-dependencies.md) · [Next: lifecycle](06-feature-lifecycle.md).
