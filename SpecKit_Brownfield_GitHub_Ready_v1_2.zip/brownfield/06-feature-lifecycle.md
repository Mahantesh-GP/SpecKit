# 06 · Execute the selected feature with Spec Kit

## The problem
Generated artifacts can look complete while containing unresolved requirements, conflicting contracts or untested behavior.

## The fix: command → review → evidence

| Stage | Developer action | Review checkpoint |
|---|---|---|
| `/speckit.specify` | Express approved scope and acceptance criteria | Compare to work item and discovery |
| `/speckit.clarify` | Resolve material ambiguity | Record owner decisions, not guesses |
| `/speckit.plan` | Design within existing architecture | Review interfaces, consumers, security and tests |
| `/speckit.tasks` | Break down implementation and verification | Include regression and dependency tasks |
| `/speckit.analyze` | Check artifact consistency | Resolve findings; human review remains necessary |
| `/speckit.implement` | Implement within approved scope | Inspect diff, build, tests, regression and PR |

**Pilot-specific:** `/speckit.converge` was used in the Adaptive Workflow pilot; its availability varies and a clean result is **not** proof of runtime behavior.

**Observed Adaptive Workflow feature:** `001-docnav-job-submission`, three priority stories, FR-001–FR-014, SC-001–SC-004, T001–T028; build reported zero errors and warnings; later activity-level DocNav submission returned **HTTP 202 Accepted** with a request ID. This does **not** establish completed OCR/callback processing, production deployment or full automated regression.

**Finish:** Compare after-change regression results with baseline; record feature tests, unresolved issues, approvals and PR/QA evidence.

## Copy/paste prompt and reference

- [Subsequent feature discovery](../prompts/05-subsequent-feature-discovery.md)

These prompts are proposed guidance adapted from the uploaded DOCX; verify outputs against the primary master evidence and current repository.
