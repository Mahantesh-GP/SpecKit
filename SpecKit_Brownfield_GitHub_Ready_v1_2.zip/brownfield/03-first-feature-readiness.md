# 03 · Select the first feature and establish a baseline

## The problem
A feature may appear complete while silently breaking existing application behavior.

## The fix
For the **first Brownfield pilot**, prefer a bounded, approved story in a project with a runnable regression suite. Run relevant tests **before** development and again **after**; add feature-specific tests.

| Existing state | Action |
|---|---|
| Regression suite passes | Record exact command, environment, date, count and results |
| Some baseline tests fail | Record pre-existing failures and obtain agreement on known baseline |
| No automated regression suite | Declare the gap; document current behavior and agree on manual smoke and/or targeted characterization tests |
| Tests not executed | Mark **not run** with reason, never **passed** |

**Readiness record:** story and owner; scope; build/test commands; baseline status; validation plan; unresolved risks; technical review.

**Evidence distinction:** Flask Todo had **27 existing tests passing** in the documented spec-only experiment. This does **not** validate the proposed pagination selector. The Adaptive Workflow pilot did **not** demonstrate a full before-and-after automated regression suite.

**Next:** [04 · Read-only feature discovery](04-read-only-feature-discovery.md).

## Copy/paste prompt and reference

- [Regression baseline inventory](../prompts/08-regression-baseline.md)

These prompts are proposed guidance adapted from the uploaded DOCX; verify outputs against the primary master evidence and current repository.
