# 02 · Create and review the Brownfield Constitution

## The problem
A generated Constitution can confuse existing standards with hypothetical engineering policies or feature-specific requirements.

## The fix
Use verified repository context **before** `/speckit.constitution`. Keep durable guardrails separate from feature requirements. Scrub invented runtimes, architecture, coverage targets, security rules and approval roles. Seek the actual authorized technical review.

### Five-section screenshot-derived template
1. Purpose & Workspace Boundaries
2. Architecture & Technical Stack Guardrails
3. Security, Authentication & Data Protection
4. Quality Minimums & Test Strategy
5. Review & Change Governance

**Caution:** The photographed template mentions .NET 8, OAuth/OIDC, Key Vault, Testcontainers, `TenantId`, 80% coverage and a Lead Architect. Those are **examples in the template**, not verified Adaptive Workflow policies. Portions of the screenshot were cropped.

**Evidence:** Adaptive Workflow Constitution screenshots showed nine engineering principles and a v1.0.0 footer; no enterprise ratification is established by that screenshot alone.

**Next:** [03 · First-feature readiness](03-first-feature-readiness.md). [Copy/paste Constitution prompt](../prompts/02-constitution.md).
