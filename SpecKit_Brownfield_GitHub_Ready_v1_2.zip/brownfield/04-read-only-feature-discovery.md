# 04 · Read-only discovery before the first feature

## The problem
Developers may not know the current call path, interfaces, consumers or existing constraints before writing a new feature specification.

## The fix: seven-step discovery

1. **Confirm boundary:** repository, solution, target project, shared libraries.
2. **Locate entry points:** trace API, UI, job, trigger or workflow through services and external calls.
3. **Read authoritative documents:** ADRs, architecture, contracts, configuration, relevant existing specs; flag outdated notes.
4. **Establish behavior and baseline:** record actual test results or missing coverage.
5. **Identify consumers/contracts:** callers, downstream integrations, shared models, storage, auth and deployment constraints.
6. **Log gaps:** cite paths, symbols, tests and questions needing owners.
7. **Peer-review the discovery:** confirm sufficiency before `/speckit.specify`.

**Expected output:** a short read-only discovery report, not a whole-repository reverse specification.

**Observed example:** The Adaptive Workflow feature targeted `WorkflowActivities` inside `AdaptiveWorkflowEngine`; DocNav was external and Commitment Typing was the consuming use case. The pilot's build and HTTP 202 evidence do not establish complete regression coverage.

[Copy/paste discovery prompt](../prompts/03-feature-discovery.md) · [Next: dependency review](05-cross-feature-dependencies.md).

## Copy/paste prompt and reference

- [Subsequent-feature focused discovery](../prompts/05-subsequent-feature-discovery.md)

These prompts are proposed guidance adapted from the uploaded DOCX; verify outputs against the primary master evidence and current repository.
