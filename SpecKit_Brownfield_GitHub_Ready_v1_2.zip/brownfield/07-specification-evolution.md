# 07 · Changing an existing feature

## The problem
A new request changes behavior already described in a previous approved feature. Simply editing `spec.md` can hide the original approved baseline and leave plan/tasks/contracts inconsistent.

## The fix
First determine whether the change belongs in a **living spec revision**, a **versioned addendum**, or a **separate change specification**. This is a review decision, not an automatic Spec Kit rule.

1. Record source, owner and approval status of the change.
2. Read original approved requirements, current code, tests and downstream artifacts.
3. Map dependent features, contracts and regression implications.
4. Choose and document the change approach with the authorized owner.
5. Reconcile plan, tasks, contracts and tests after authorization; run consistency checks.
6. Implement only when approved and validate existing plus new behavior.

**Actual experiment:** Todo feature `003` used a 10-item page size; `AMD-001` proposed 10/20/50 choices with default 10. This was **unapproved and spec-only**. Do not claim implementation or a winning specification-evolution strategy.

[Next: cross-feature dependency assessment](05-cross-feature-dependencies.md).

## Copy/paste prompt and reference

- [Specification change impact prompt](../prompts/06-specification-change-impact.md)

These prompts are proposed guidance adapted from the uploaded DOCX; verify outputs against the primary master evidence and current repository.
