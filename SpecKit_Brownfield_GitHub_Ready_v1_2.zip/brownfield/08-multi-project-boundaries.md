# 08 · Large and multi-project repositories

## The problem
A solution with many `.csproj` files can tempt developers to initialize Spec Kit for every project or send the entire codebase to an AI model.

## The fix
Agree on the repository/workspace boundary and governing rules; then use **focused context** for the selected feature. A shared repository-level Constitution is a sensible *starting point* where governance is shared, not a universal rule for independent domains.

**Adaptive Workflow boundary:** `AdaptiveWorkflowEngine` is the multi-project framework; `WorkflowActivities` is one project; Commitment Typing is a consumer; DocNav is an external service. Preserve orchestration and registration patterns while targeting the integration activity.

**Context selection:** orientation (repo map + Constitution) → relevant feature slice → expand only for evidenced dependencies → verify with source and tests.

**Repomix limitation:** the observed 13-file `WorkflowActivities` package was **not** a complete solution-wide architecture inventory; estimated package tokens are **not** total Copilot session cost or measured savings.

## Copy/paste prompt and reference

- [Multi-project discovery prompt](../prompts/07-multi-project-discovery.md)

These prompts are proposed guidance adapted from the uploaded DOCX; verify outputs against the primary master evidence and current repository.
