# Prompt · Multi-project repository: scoped read-only discovery

> **Status:** Proposed developer prompt adapted from DOCX Chapter 6 §6.7 (adapted). Not a verbatim executed pilot prompt. Confirm paths, owners and approvals.

```text
We are adopting Spec Kit for one change in an existing multi-project repository.
READ-ONLY: do not edit files, initialize tools, run implementation commands or change ADO.
Selected story: [ADO ID / approved change description].

1. Map repository root, solution/projects, deployable services, shared libraries and
   test projects; cite exact paths.
2. Identify feature entry points, code paths, contracts, storage, configuration,
   external services and likely consumers.
3. Read relevant architecture/ADRs, active constitution and feature specs;
   distinguish approved sources from drafts.
4. Classify dependencies as CONFIRMED (with evidence), POSSIBLE/UNVERIFIED or OUT OF SCOPE.
5. List existing tests, regression gaps, owners to consult and open decisions.
6. Propose the smallest relevant set of files/docs for Spec Kit context; avoid unrelated modules.
7. Return a concise repository map, feature-context note and open-questions table.

Do not claim approval or test execution without evidence. Stop after the report.
```
