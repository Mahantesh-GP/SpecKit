# Prompt · Draft a Constitution from reviewed context

> Proposed prompt recorded in the master evidence; **not** proof of the original exact pilot prompt.

> **Reference:** Master evidence: proposed Constitution prompt and screenshot-derived template; DOCX Chapter 1 §1.5. Adapted prompt; not an exact recorded execution transcript.

```text
/speckit.constitution

We are introducing GitHub Spec Kit into an existing Brownfield application.
Before drafting, review the verified repository context provided:
- Repomix package: [path/to/reviewed-package.md] OR
- GitHub Copilot project-discovery report: [path/to/reviewed-discovery-report.md]
Also consult authoritative architecture documents, build/test configuration and existing standards.

Identify verified stack/runtimes, module boundaries, dependency and integration patterns,
authentication/security/secrets practices, coding/error handling, actual tests/CI and
existing review/change governance.

Draft reusable repository-level guardrails, not requirements for one feature.
Distinguish confirmed standards from proposed recommendations. Do not invent technologies,
coverage percentages, security policies, compliance obligations, roles or approval requirements.
Cite supporting paths where possible; flag missing scope and conflicting evidence.
Do not assume the supplied package covers the whole solution.
Present as DRAFT for authorized technical review, not as approved policy.
```
