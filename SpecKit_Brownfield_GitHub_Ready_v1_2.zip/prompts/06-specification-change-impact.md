# Prompt · Existing-feature specification change: read-only comparison

> **Status:** Proposed developer prompt adapted from DOCX Chapter 4 §4.5 (adapted; example generalized). Not a verbatim executed pilot prompt. Confirm paths, owners and approvals.

```text
Assess a proposed change to an existing Brownfield feature.
READ-ONLY: do not edit files, execute Spec Kit commands, change code or update Azure DevOps.
Baseline feature: [feature ID/path and approved baseline].
Proposed change: [change request/ID, approval status and proposed behavior].

1. Identify last approved requirements; distinguish unapproved experimental text.
2. List impacted requirement IDs, plan/tasks, research, data model, contracts, code,
   tests and dependent features. Mark each impact VERIFIED or INFERRED.
3. Compare in-place living-spec revision, versioned addendum and separate change spec.
4. For each option, show traceability, preservation of approval history, reviewer effort and risks.
5. Recommend a candidate for discussion; do not declare enterprise policy or approval.
6. Produce a short decision record, unanswered questions and next validation steps.

Stop after read-only comparison.
```
