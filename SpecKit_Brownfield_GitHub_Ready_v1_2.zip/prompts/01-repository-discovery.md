# Prompt · Repository discovery (Copilot Chat, read-only)

> **Reference:** DOCX Chapter 1 §1.5; master evidence: repository discovery and Repomix observations. Adapted prompt; not an exact recorded execution transcript.

```text
Act as a read-only Brownfield repository discovery assistant.
Repository/workspace: [repository root]
Goal: prepare verified context before creating a Spec Kit Constitution.

Inspect actual solution/project/build files, architecture and ADRs, API/contracts,
configuration, existing tests/CI, security conventions and existing approved standards.
Identify repository and module boundaries, runtime versions, entry points, dependency
patterns, build/test commands and unresolved questions. Cite exact file paths and symbols.
Separate verified facts, inferred findings and recommendations requiring approval.
Do not invent coverage thresholds, technologies, approval roles or security policies.
Do not edit files, initialize Spec Kit, run implementation commands or modify ADO.
Return a concise evidence-backed report and stop for review.
```
