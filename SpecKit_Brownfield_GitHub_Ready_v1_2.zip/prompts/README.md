# Copy/paste prompts — Brownfield Spec Kit

Use these prompts in the relevant **stage**, with placeholders replaced and findings reviewed. Read-only prompts do not authorize edits or test execution. Prompts are **proposed/adapted guidance**, not verbatim historical pilot transcripts.

| When | Prompt | Reference basis |
|---|---|---|
| Before Constitution | [Repository discovery](01-repository-discovery.md) | DOCX Ch. 1 §1.5; master repository evidence |
| Drafting Constitution | [Constitution](02-constitution.md) | Master Constitution prompt; DOCX Ch. 1 §1.5 |
| Before first feature | [Regression baseline inventory](08-regression-baseline.md) | Master readiness; DOCX Ch. 2 §2.4 |
| Before first feature | [Read-only feature discovery](03-feature-discovery.md) | Master seven-step sequence; DOCX Ch. 2 §2.5 |
| New feature depends on previous features | [Cross-feature dependency discovery](04-cross-feature-dependencies.md) | Master Todo 003→004; DOCX Ch. 5 §5.5 |
| Feature 2 onward | [Focused subsequent-feature discovery](05-subsequent-feature-discovery.md) | DOCX Ch. 3 §3.4 |
| Changing existing feature | [Specification change impact](06-specification-change-impact.md) | Master AMD-001; DOCX Ch. 4 §4.5 |
| Large/multi-project solution | [Multi-project discovery](07-multi-project-discovery.md) | Master Adaptive Workflow; DOCX Ch. 6 §6.7 |

**Evidence hierarchy:** [Master Evidence](../evidence/SpecKit_Pilots_Master_Evidence_2026-10-28.md) governs factual pilot claims; the uploaded DOCX is a secondary reference for structure and prompt patterns. See [SOURCE-MAP](../SOURCE-MAP.md). No prompt guarantees full dependency coverage or regression safety.
