# Prompt · Subsequent-feature focused discovery

> **Status:** Proposed developer prompt adapted from DOCX Chapter 3 §3.4 (adapted; proposed guidance). Not a verbatim executed pilot prompt. Confirm paths, owners and approvals.

```text
We are preparing the NEXT feature in an existing repository using Spec Kit.
Do READ-ONLY discovery. Do not edit code, specs, constitution, tasks, or ADO items.
Feature/work item: [ID and approved description].
Acceptance criteria: [paste approved criteria].

1. Read the current constitution and relevant existing specs/architecture notes.
2. Trace the feature's existing entry points, modules, interfaces, data flow, and tests.
3. Identify cross-feature dependencies, external contracts, and in-flight overlaps.
4. Separate VERIFIED repository facts from assumptions and open questions.
5. State what prior discovery can be reused and what needs revalidation.
6. Recommend a feature boundary; flag if this changes an existing approved feature.
7. Propose regression areas and the minimum decisions needed before /speckit.specify.

Return a concise evidence table with file paths and unanswered questions.
Stop after the discovery report; do not run Spec Kit commands.
```
