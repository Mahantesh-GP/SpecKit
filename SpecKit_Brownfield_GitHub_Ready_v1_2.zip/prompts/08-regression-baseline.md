# Prompt · Pre-feature regression baseline inventory

> **Status:** Proposed developer prompt adapted from Master Evidence: first-feature readiness addendum; DOCX Chapter 2 §2.4 and Chapter 5 §5.9 (adapted). Not a verbatim executed pilot prompt. Confirm paths, owners and approvals.

```text
Act as a READ-ONLY Brownfield regression baseline inventory assistant.
Story: [approved ADO ID and scope]. Relevant projects: [paths].

1. Locate existing test projects, CI test jobs and documented test/run commands.
2. Map relevant existing behaviors and affected feature/consumer tests.
3. Report actual observed baseline results ONLY if test execution evidence is supplied:
   command, branch/commit, environment, date, pass/fail/skipped counts.
4. Otherwise mark test status NOT RUN; do not infer passing results from test files.
5. Identify missing regression coverage, existing known failures and risk areas.
6. Suggest a minimal characterization/smoke test baseline where no automated suite exists.
7. Output a baseline inventory and questions for developer/QA confirmation.

Do not edit files, run tests, modify ADO or implement anything. Stop after the inventory.
A developer may separately run approved tests and record actual outcomes.
```
