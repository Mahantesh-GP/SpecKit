# Source hierarchy and editorial rules

**Primary source of factual pilot claims:** `evidence/SpecKit_Pilots_Master_Evidence_2026-10-28.md` (copied without modification).

**Secondary structure reference:** uploaded `Brownfield_SDD_Adoption_Guide_v1_4_Community_Context_Practices.docx`, especially its six chapters and Chapter 5 dependency framework. It supplies *proposed guidance*, not new proof of pilot execution.

| Page | Master evidence anchor | Status |
|---|---|---|
| Project discovery | Repomix addenda; architecture boundary | Pilot observation + proposed workflow |
| Constitution | Constitution screenshot template and GHCP prompt | Screenshot-derived template; prompt proposed |
| First-feature readiness | First-feature readiness addendum | Recommended; Todo baseline observed |
| Read-only feature discovery | Seven-step sequence | Recommended, not proven all completed |
| Cross-feature dependencies | Todo 003→004 and AMD-001; DOCX Chapter 5 | Dependency observed; impact review recommended |
| Lifecycle | Adaptive Workflow S01–S07 and Todo evidence | Recorded; limitations explicit |
| Specification evolution | Todo AMD-001 | Unapproved spec-only experiment |
| Multi-project boundaries | Adaptive Workflow solution structure | Recorded |

**Editorial rule:** Never turn an example Constitution threshold or an untried community tool into a verified enterprise rule. Do not treat HTTP 202 as DocNav processing completion, or a passing baseline as new-feature validation. Keep exact screenshots, logs, commits and approval gaps visible.

## Prompt provenance (v1.1)

Prompts are adapted, not exact executed transcripts. The primary master evidence controls claims about actual pilot runs. The DOCX supplies recommended prompt wording and chapter placement:

- Chapter 1 §1.5: repository discovery/Constitution input; Constitution draft must remain reviewable.
- Chapter 2 §§2.4–2.5: seven-step first-feature read-only discovery and baseline evidence.
- Chapter 3 §3.4: focused discovery for feature 2 onward.
- Chapter 4 §4.5: read-only comparison of proposed changes to approved features.
- Chapter 5 §5.5: cross-feature dependency discovery and impact matrix.
- Chapter 6 §6.7: multi-project discovery.
- Regression inventory prompt: new adaptation from master readiness and DOCX Chapter 2 §2.4 / Chapter 5 §5.9; **not** an original DOCX verbatim prompt.

Every prompt links from `prompts/README.md`; stage pages link to their applicable prompts.
