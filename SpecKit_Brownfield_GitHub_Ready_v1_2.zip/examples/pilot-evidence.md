# Pilot examples — what was observed and what remains unverified

## Adaptive Workflow / DocNav

**Recorded:** existing multi-project `AdaptiveWorkflowEngine`; feature `001-docnav-job-submission` in `WorkflowActivities`; Spec Kit lifecycle including pilot-specific Converge; build zero errors/warnings; after credential/Blob URL corrections, **activity-level DocNav HTTP 202 Accepted** with request ID.

**Not established:** production deployment, downstream OCR/callback completion, full Commitment Typing implementation, complete before/after regression suite, formal enterprise ratification or measured time savings.

**Repomix:** `workflowActivity.md`, 13 selected files, ~7,017 estimated tokens, 34,840 characters; only selected `WorkflowActivities` files. No evidence it was passed to the original Constitution command.

## Flask Todo Brownfield

**Recorded:** 27 existing baseline tests passed; Repomix `todo-context.md` with 5 selected files, ~2,249 estimated tokens; feature `003` pagination baseline with `PAGE_SIZE=10`; feature `004` dependency on `003`.

**Unapproved experiment:** `AMD-001` spec-only proposed selector 10/20/50, default 10. No demonstrated selector implementation, acceptance or end-to-end validation.

## Separate .NET Todo sample

.NET 8 / React / SQL Server Todo is a **different** Spec Kit/ADO sample. Do not conflate it with the Flask Todo screenshots or tests.

## Evidence caution

This guide derives factual claims from [`SpecKit_Pilots_Master_Evidence_2026-10-28.md`](../evidence/SpecKit_Pilots_Master_Evidence_2026-10-28.md). The source register flags screenshot-to-file and PR/commit mapping still pending. Avoid publishing secrets or unredacted internal identifiers.
